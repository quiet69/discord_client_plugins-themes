# SpotiMbed
A [replugged](https://github.com/replugged-org/replugged) plugin for making Spotify embeds actually useable

### Preview
![Track Embed](https://i.imgur.com/5x2gyyd.png)
