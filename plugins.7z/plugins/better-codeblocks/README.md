# Better Codeblocks

[Install in Replugged](https://replugged.dev/install?url=replugged-org/better-codeblocks)

Improve Discord's codeblocks with the language name and a button to copy the contents.

Originally part of the official set of [Powercord plugins](https://github.com/powercord-org/powercord/tree/v2/src/Powercord/plugins).
