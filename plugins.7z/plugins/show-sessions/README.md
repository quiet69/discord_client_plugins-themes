# Show Sessions
Port of Strencher's plugin (https://github.com/Strencher/BetterDiscordStuff/tree/master/ShowSessions) to Powercord