# Mock

[Install in Replugged](https://replugged.dev/install?url=replugged-org/mock)

A command to mock people lIkE tHiS. Formerly `pc-mock`.

Originally made by [Melmsie](https://github.com/melmsie) as part of the official set of [Powercord plugins](https://github.com/powercord-org/powercord/tree/v2/src/Powercord/plugins).
