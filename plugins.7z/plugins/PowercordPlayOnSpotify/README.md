# Play On Spotify

A powercord plugin that Adds Play/Queue buttons to messages containing spotify embeds. Clicking them will play or queue the songs on Spotify instead of playing the stupid preview in discord


Supports songs, albums or playlists. Queue is only available for songs.

NOTE: This plugin uses the Spotify API wrapper from the pc-spotify module, so make sure you have that set up properly

![screenshot](https://i-dont.work-for-an.agency/9ioWTK1.png)

![screenshot](https://uwu.whats-th.is/7g3WDkM.png)

---

### Icon Credit

Queue Icon made by Pixel perfect from www.flaticon.com

Play Icon made by Freepik from www.flaticon.com
