# Total Members

Shows a counter of the total amount of members in a server on the members list.
