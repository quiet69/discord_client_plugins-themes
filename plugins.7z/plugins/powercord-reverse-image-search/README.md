# powercord-reverse-image-search

A plugin for powercord which allows users to reverse image search media by right simply right clicking.

> Note: This plugin utilizes lazy-loading, you may need to right click twice the first time you want to search for an image.

**Supports:**

-   Emojis
-   Images
-   User Avatars
-   Guild Icons

| Messages                             | Avatars                              |
| ------------------------------------ | ------------------------------------ |
| ![](https://i.imgur.com/mwixT5T.gif) | ![](https://i.imgur.com/2leN7um.png) |

| Settings                             |
| ------------------------------------ |
| ![](https://i.imgur.com/h19Z9Zr.png) |

---

**Twitter:** [twitter.com/lorencerri](https://twitter.com/lorencerri) <br>
**Discord:** [discord.gg/plexidev](https://discord.gg/plexidev)
