# AvatarIconViewer
## Allows you to view Avatars & Copy them via ContextMenu.
- [Support Server](https://discord.gg/gvA2ree)
