# Share Plugins

Allows you to share plugins that you have installed with others so you don't have to look for the link.

This is done by looking for the `.git` folder and searching for the git url.