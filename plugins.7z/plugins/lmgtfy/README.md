# LMGTFY

[Install in Replugged](https://replugged.dev/install?url=replugged-org/lmgtfy)

The perfect answer to people who would rather waste your time and their own than use Google for themselves.

Originally part of the set of official [Powercord plugins](https://github.com/powercord-org/powercord/tree/v2/src/Powercord/plugins) as `pc-lmgtfy`.
