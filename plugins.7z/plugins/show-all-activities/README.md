# show-all-activities
Shows all user activities in places that Discord doesn't show them.

![preview](https://i.imgur.com/MYCfZon.jpg)

![collapsible activities](https://i.imgur.com/ZqTxvY2.png)
