# user-details
Powercord plugin. Displays when user created account, joined to server and when sent last or first message in selected server / dm.
