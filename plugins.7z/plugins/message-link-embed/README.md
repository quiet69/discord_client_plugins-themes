# message-link-embed
Powercord plugin. Make message links show an embed like invites or store links.

![preview](https://i.imgur.com/0B1ts0P.png)
