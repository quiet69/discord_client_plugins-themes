# This plugin has been archived, it should continue to work in the future because Powercord is not updating v2 internals anymore.

# Theme Toggler
Simple plugin for [Powercord](https://powercord.dev) that allows toggling themes.

## Installation
1. Go to your powercord plugins folder. Run `git clone https://github.com/redstonekasi/theme-toggler`
2. Restart discord or fetch missing plugins.
