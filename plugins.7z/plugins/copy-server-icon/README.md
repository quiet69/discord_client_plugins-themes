# Copy Server Icon URL
A powercord plugin to copy a server icon's url from it's context menu.
