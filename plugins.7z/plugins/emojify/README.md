[![forthebadge](https://forthebadge.com/images/badges/works-on-my-machine.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/it-works-why.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/mom-made-pizza-rolls.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/just-plain-nasty.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/you-didnt-ask-for-this.svg)](https://forthebadge.com)
# emojify
An 😍📯 powercord plugin made 👑🍔 to 💦💦 turn 👆🏼 any message 👾 that you send into 👉👉 a 💰🏻 emojipasta 👌

## Screenshots:
![](https://i.imgur.com/kCZ3B1j.png)
![](https://i.imgur.com/vNKNbCn.png)
