# Emoji Utility

[Install in Replugged](https://replugged.dev/install?url=replugged-org/emoji-utility)

Emote-related commands.

Originally made by [Joakim](https://github.com/21Joakim) as part of the original set of official [Powercord plugins](https://github.com/powercord-org/powercord/tree/v2/src/Powercord/plugins).
