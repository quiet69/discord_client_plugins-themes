# Image To Clipboard
Adds a button to the message context menu which allows you to copy images straight to your system's clipboard.