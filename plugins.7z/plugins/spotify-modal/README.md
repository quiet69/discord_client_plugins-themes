# Spotify Modal

[Install in Replugged](https://replugged.dev/install?url=replugged-org/spotify-modal)

Better Spotify integration in Discord. Originally part of the set of official [Powercord plugins](https://github.com/powercord-org/powercord/tree/v2/src/Powercord/plugins) as `pc-spotify`.

To comply with the ToS of Spotify's API, playback controls require Spotify premium.
