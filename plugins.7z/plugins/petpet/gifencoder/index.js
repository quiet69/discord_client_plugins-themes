module.exports = require("./GIFEncoder");
