# petpet

A powercord plugin to create pet gifs

Inspired by <https://benisland.neocities.org/petpet/>

## Example

<!-- Ignore the horrible table formatting -->
| Input  | Output  |
|---|---|
| ![Input](https://cdn.discordapp.com/attachments/769715970502557727/857766059394596894/97a3135fe0eaae28526bb80e1bb8fb86.png) | ![Output](https://media.discordapp.net/attachments/769715970502557727/857765131320819712/petpet.gif) |

## Usage

`[p]` is your powercord command prefix, `.` by default

```sh
[p]petpet <IMAGE_URL | UserID / Mention> [FILE_NAME - default pet.gif] [DELAY - default 20)] [RESOLUTION - default 128]
```
