# Message Translate libless edition

Translates messages to and from languages semi-automagically. Forked edition without the shitty lib and which will
be more compatible with Powercord features.
