# SmoothScrollPowerCord
Animate smoothly when scrolling though discord!

## How to install?

`cd %HOMEPATH%\powercord\src\Powercord\plugins && git clone https://github.com/Hot-Tutorials/SmoothScrollPowerCord`
