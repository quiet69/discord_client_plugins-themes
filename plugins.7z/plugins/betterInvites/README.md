# Better Invites
A powercord port of bakzkndd#2819's vizality plugin in order to make invites more handsome and beautiful.

This is bakzkndd's plugin: https://github.com/bakzkndd/BetterInvites/