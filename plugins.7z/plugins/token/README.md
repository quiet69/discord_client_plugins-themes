# token
A really simple plugin to get your Discord token via a command

![Screenshot 2021-09-25 204106](https://user-images.githubusercontent.com/84019509/134788574-c1f41b01-e214-4b7b-8c3c-fc6db1e8c111.png)

Inspired by zt64 Aliucord plugin, and I used WolfPlugs osu plugin as a base

Usage:
```{prefix}token```
